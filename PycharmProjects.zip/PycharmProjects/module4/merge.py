
def merge_sorted(a,b):
    c = []
    while len(a) > 0 or len(b) > 0:
        if len(b) == 0:
            for i in a:
                c.append(i)
            return c
        elif len(a) == 0:
            for i in b:
                c.append(i)
            return c
        elif a[0] < b[0]:
            c.append(a[0])
            a.pop(0)
        elif a[0]>b[0]:
            c.append(b[0])
            b.pop(0)
        else:
            c.append(a[0])
            c.append(b[0])
            a.pop(0)
            b.pop(0)
    return c





a = [1,3,5,6,10]
b = [1,4,6,8]

print(merge_sorted(a,b))