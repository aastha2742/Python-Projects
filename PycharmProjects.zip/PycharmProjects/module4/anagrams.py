
def is_anagram_of(a, b):
    a_freq = count_words(a)
    b_freq = count_words(b)
    if a_freq == b_freq:
        return True
    return False


def count_words(string):
    counts = {}
    words = string.lower().split()
    for word in words:
        for letter in word:
            if letter in counts:
                counts[letter] += 1
            else:
                counts[letter]=1
    return counts

print(is_anagram_of('hi hell','hello hi'))
