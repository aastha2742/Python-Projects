def cross_out_multiples(is_prime,n):
    for i in range(2, n):
        index = `
        if is_prime[i]:
            for j in range(i*i,n,i):
                is_prime[j]= False
    return is_prime


def sieve(n):
    primes = []
    is_prime = [True for l in range(0,n+1)]
    bool_list = cross_out_multiples(is_prime, n+1)
    for i in range(len(bool_list)-1):
        if bool_list[i] and i < n+1:
            primes.append(i)
    return primes

#
l = [True for i in range(0, 20)]
print(cross_out_multiples(l, 3))
# l = [True for i in range(0,20)]
# cross_out_multiples(l,3)
# print(sieve(4))