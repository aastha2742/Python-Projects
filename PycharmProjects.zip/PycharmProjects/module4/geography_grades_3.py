
import sys


def read_file():
    person_list = []
    groups = sys.stdin.read().split('=\n')
    for line in groups:
        person_list.append(line.split('\n'))
    return person_list


def calculate_avg(grades):
    sum = 0
    grade_list = grades.split(' ')
    for grade in grade_list:
        if (grade != ""):
            sum += float(grade)
    return sum/len(grade_list)


def parse_data(list):
    tuple_list = []
    for person in list:
        name = person.split('_')[0]
        avg_grade = calculate_avg(person.split('_')[-1])
        tuple_list.append((name, avg_grade))
    return tuple_list


def round_off(grade):
    if grade % 1 == 0.5:
        return grade
    else:
        return round(grade*2)/2

def round_up(grade):
    if grade == 5.5:
        grade += .5
    return grade


def print_data(group_num,tuple_list):
    print('Report for group',group_num)
    for person in tuple_list:
        if person[1] != 0:
            print(person[0], 'has a final grade of', round_up(round_off(person[1])))
    print('End of report \n')


def main():
    group_list = read_file()
    for group in group_list:
        group_num = group[0]
        group.remove(group_num)
        person_list = parse_data(group)
        print_data(group_num,person_list)

main()
