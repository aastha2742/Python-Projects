import unittest
from sieve import cross_out_multiples, sieve
from anagrams import is_anagram_of
from merge import merge_sorted

class Tests(unittest.TestCase):

  def test_anagram(self):
      self.assertTrue(is_anagram_of("eleven plus two", "twelve plus one"))
      self.assertTrue(is_anagram_of("William Shakespeare", "I am a weakish speller"))
      self.assertTrue(is_anagram_of("Tom Marvolo Riddle","I am Lord Voldemort"))
      self.assertTrue(is_anagram_of("Anagrams","Ars magna"))
      self.assertTrue(is_anagram_of("television ads", "enslave idiots"))
      self.assertFalse(is_anagram_of("cat","tact"))
      self.assertFalse(is_anagram_of("bla","aalb"))
      self.assertFalse(is_anagram_of("you", "me"))
      self.assertFalse(is_anagram_of("wooo","weee"))

  def test_merge(self):
    a= [1, 3, 5, 6, 10]
    b = [1, 4, 6, 8]
    ans = [1, 1, 3, 4, 5, 6, 6, 8, 10]
    self.assertEqual(merge_sorted(a,b),ans)
    a = [1, 3, 5, 7, 9]
    b = [2, 4, 6, 8]
    ans = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    self.assertEqual(merge_sorted(a, b), ans)
    a = [1, 2, 5, 8, 10]
    b = [2, 2, 6, 8, 9]
    ans = [1, 2, 2, 2, 5, 6, 8, 8, 9, 10]
    self.assertEqual(merge_sorted(a, b), ans)
    a = [1, 3, 5, 10]
    b = [2, 8]
    ans = [1, 2, 3, 5, 8, 10]
    self.assertEqual(merge_sorted(a, b), ans)
    a = [1, 4, 6, 10, 12]
    b = [1, 2, 3, 5, 6, 7, 8, 9, 10, 13, 14]
    ans = [1, 1, 2, 3, 4, 5, 6, 6, 7, 8, 9, 10, 10, 12, 13, 14]
    self.assertEqual(merge_sorted(a, b), ans)


  def test_cross_out_multiples(self):
    l = [True for i in range(0,20)]
    cross_out_multiples(l, 3)
    self.assertEqual(l[4:],[True, True, True, False, True, True, False, True, True, False, True, True, False, True, True, False, True, True, False, True][4:])
    l = [True for i in range(0,30)]
    cross_out_multiples(l, 4)
    self.assertEqual(l[5:],[i % 4 != 0 for i in range(0,30)][5:])
    l = [True for i in range(0,100)]
    cross_out_multiples(l, 2)
    self.assertEqual(l[3:],[i % 2 != 0 for i in range(0,100)][3:])

  def test_sieve(self):
    self.assertEquals(sieve(20), [2, 3, 5, 7, 11, 13, 17, 19])
    self.assertEquals(sieve(100), [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97])
    self.assertEquals(sieve(1000), [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997])

if __name__ == '__main__':
    unittest.main()
