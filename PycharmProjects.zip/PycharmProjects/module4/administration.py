import sys


def read_file():
    list = []
    for line in sys.stdin.readlines():
        if line != '\n':
            list.append(line)
    return list


def calculate_avg(grades):
    sum = 0
    grade_list = grades.split(' ')
    for grade in grade_list:
        sum += float(grade)
    return sum/len(grade_list)


def parse_grades(list):
    tuple_list = []
    for grades in list[::2]:
        avg_grade = calculate_avg(grades.split('_')[-1])
        name = grades.split('_')[0]
        tuple_list.append((name,avg_grade))
    return tuple_list


def score_graph(string):
    scores = string.split('=')
    graph = ''
    for i in scores:
        if float(i) == 0:
            graph = graph+'_'
        elif float(i) >= 20:
            graph = graph+'^'
        else:
            graph = graph+'-'
    return graph


def parse_similarty_score(list):
    tuple_list = []
    for scores in list[1::2]:
        score = score_graph(scores.split(';')[0])
        matches = str(scores.split(';')[-1].replace(',', '\n'))
        tuple_list.append((score,matches))
    return tuple_list

def round_off(grade):
    if grade % 1 == 0.5:
        return grade
    else:
        return round(grade*2)/2

def round_up(grade):
    if grade >= 5.5 and grade < 6:
        grade = '6-'
    return grade


def final(tupleA,tupleB):
    print (tupleA[0],'has an average of',round_up(round_off(tupleA[1])))
    if tupleB[1] == '\n':
        print(tupleB[0],'\n',"No matches found",'\n')
    else:
        print(tupleB[0], '\n' ,tupleB[1])



def main():
    list = read_file()
    tupleA = parse_grades(list)
    tupleB = parse_similarty_score(list)
    for i in range(len(tupleA)):
        final(tupleA[i], tupleB[i])

main()



