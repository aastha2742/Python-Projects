import sys


def read_file():
    person_list = []
    for line in sys.stdin.readlines():
        if line != '\n':
            person_list.append(line)
    return person_list


def calculate_avg(grades):
    sum = 0
    grade_list = grades.split(' ')
    for grade in grade_list:
        sum += float(grade)
    return sum/len(grade_list)



def parse_data(list):
    tuple_list = []
    for person in list:
        name = person.split('_')[0]
        avg_grade = calculate_avg(person.split('_')[-1])
        tuple_list.append((name, avg_grade))
    return tuple_list


def print_data(tuple_list):
    print('Report for group 2b')
    for person in tuple_list:
        print(person[0], 'has an average grade of', round(person[1],1))
    print('End of report')


def main():
    person_list = read_file()
    person_list = parse_data(person_list)
    print_data(person_list)

main()
