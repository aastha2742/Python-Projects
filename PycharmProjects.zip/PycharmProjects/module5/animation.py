import snakelib

width = 0  # initialized in play_animation
height = 0  # initialized in play_snake
ui = None  # initialized in play_animation
SPEED = 5
keep_running = True
X = 0
Y = 0
color_green = 1

def draw():
    global X, Y, color_green
    ui.clear()
    if color_green == 1:
        ui.place(X, Y, ui.SNAKE)
    else:
        ui.place(X, Y, ui.FOOD)
    if Y == height-1 and X == width-1:
        X = 0
        Y = 0
    elif X == width-1:
        Y += 1
        X = 0
    else:
        X += 1
    ui.show()


def play_animation(init_ui):
    global width, height, ui, keep_running, color_green
    ui = init_ui
    width, height = ui.board_size()
    draw()
    while keep_running:
        event = ui.get_event()
        if event.name == "alarm":
            draw()
        # make sure you handle the quit event like below,
        # or the test might get stuck in an infinite loop
        if event.name == "quit":
            keep_running = False
        if event.data == 'space':
            color_green *= -1


if __name__ == "__main__":
    # do this if running this module directly
    # (not when importing it for the tests)
    ui = snakelib.SnakeUserInterface(10, 10)
    ui.set_animation_speed(SPEED)
    play_animation(ui)

