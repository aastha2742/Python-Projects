import snakelib

width = 0  # initialized in play_snake
height = 0  # initialized in play_snake
ui = None  # initialized in play_snake
SPEED = 1
X = 1
Y = 0
apple_location = (0, 0)
keep_running = True
direction = 'r'
snake_length = [(0, 0), (1, 0)]


def place_apple():
    global snake_length, width, height, apple_location, ui
    numbered_list = list(range(height * width))
    nrFreeSpots = width*height - len(snake_length)
    location = ui.random(nrFreeSpots)
    x = 0
    new_list = []
    for i in numbered_list:
        coord_y = int(i/width)
        coord_x = i - height * coord_y
        if (coord_x,coord_y) in snake_length:
            numbered_list[numbered_list.index(i)] = 'X'

    for i in numbered_list:
        if type(i) == int:
            new_list.append(x)
            x += 1
        else:
            new_list.append(i)

    for i in new_list:
        if i == location:
            coord_y = int(new_list.index(i) / width)
            coord_x = int(new_list.index(i) - width * coord_y)
            apple_location = (coord_x, coord_y)


def move_snake():
    global direction, X, Y, width
    if direction == 'r':
        X += 1
    elif direction == 'l':
        X -= 1
    elif direction == 'u':
        Y -= 1
    else:
        Y += 1
    if Y == height:
        Y = 0
    elif Y == -1:
        Y = height - 1
    elif X == width:
        X = 0
    elif X == -1:
        X = width - 1


def play_snake(init_ui):
    global width, height, ui, keep_running, direction, X, Y, apple_location
    ui = init_ui
    width, height = ui.board_size()
    place_apple()
    print(apple_location)
    ui.place(apple_location[0], apple_location[-1], ui.FOOD)
    for coordinate in snake_length:
        ui.place(coordinate[0], coordinate[-1], ui.SNAKE)
    ui.show()
    while keep_running:
        event = ui.get_event()
        if event.name == "alarm":
            ui.clear()
            move_snake()
            snake_length.append((X, Y))
            if (X, Y) == apple_location:
                place_apple()
            else:
                del snake_length[0]
            if (X, Y) in snake_length[0:-2]:
                ui.set_game_over()
            for coordinate in snake_length:
                ui.place(coordinate[0], coordinate[-1], ui.SNAKE)
            ui.place(apple_location[0], apple_location[1], ui.FOOD)
            ui.show()
        elif event.data != direction:
            direction = event.data
        # make sure you handle the quit event like below,
        # or the test might get stuck in an infinite loop
        if event.name == "quit":
            keep_running = False


if __name__ == "__main__":
    # do this if running this module directly
    # (not when importing it for the tests)
    ui = snakelib.SnakeUserInterface(10, 10)
    ui.set_animation_speed(SPEED)
    play_snake(ui)
