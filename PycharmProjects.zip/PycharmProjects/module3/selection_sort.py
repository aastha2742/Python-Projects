def index_of_min(l, start_index):
    for i in range(start_index, len(l)):
        if l[i] < l[start_index]:
            start_index = i
    return start_index


# l = [16, 5, 10, 17, 18, 9]
# print(index_of_min([15, 3, 0, 2, 11, 9, 4, 7, 7, 8, 11, 9, 5, 1, 0, 18, 10, 19, 13], 4))


def selection_sort(l):
    for i in range(len(l)):
        index = index_of_min(l, i)
        if l[index] < l[i]:
            l[index], l[i] = l[i], l[index]
    print(l)

# selection_sort([15, 3, 0, 2, 11, 9, 4, 7, 7, 8, 11, 9, 5, 1, 0, 18, 10, 19, 13])
