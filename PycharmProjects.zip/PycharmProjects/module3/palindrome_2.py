# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: PALINDROME 2

def palindrome2(character):
    alphabet = ''
    backwards_alphabet = ''
    for i in range(ord('a'), ord(character) + 1):
        alphabet += chr(i)
        if alphabet[-1] == character:
            for j in range(ord('a'), ord(character)):
                backwards_alphabet += chr(j)
    print(alphabet + backwards_alphabet[::-1])


palindrome2(input('Enter a letter:'))




