# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: PALINDROME 3

def is_palindrome(s):
    s_reversed = s[::-1]
    if s_reversed == s:
        return True
    else:
        return False


