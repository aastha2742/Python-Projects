# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: PALINDROME 3

def pyramid(character, layer=1):
    alphabet = list(map(chr, range(ord('a'), ord(character) + 1)))
    while layer <= len(alphabet):
        new_alphabet = alphabet[:layer]
        pyramid_layer = ''.join([letter for letter in new_alphabet] + [letter for letter in reversed(new_alphabet[:-1])])
        print('{:^32}'.format(pyramid_layer))
        layer += 1


pyramid(input('Enter a letter:'))
