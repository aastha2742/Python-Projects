# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: PALINDROME 1

# def to_seconds(hours,minutes,seconds) :
#   pass # <- fix me

def to_seconds(hours, minutes, seconds):
  seconds_in_hours = 3600
  seconds_in_minutes = 60
  total_seconds = (hours*seconds_in_hours) + (minutes*seconds_in_minutes) + seconds
  return total_seconds

print(to_seconds(2, 30, 10))

