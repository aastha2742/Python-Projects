# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: PALINDROME 1


def palindrome1( ):
    alphabet = ''
    for i in range(ord('a'), ord('z')+1):
        alphabet += chr(i)
        if chr(i) == 'y':
            backwards_alphabet = alphabet[::-1]
    print(alphabet+backwards_alphabet)

palindrome1( )



