
def factorial(n):
    if n == 1 or n == 0:
        return 1
    return n * factorial(n-1)

def choose(n, k):
    possibilites = factorial(n)/((factorial(k))*(factorial(n-k)))
    return possibilites

def main():
    marios_pizza = int(choose(10,3))
    luigis_pizza = int(choose(9,4))
    print('Mario can make', marios_pizza,'pizzas.')
    print('Luigi can make', luigis_pizza,'pizzas.')
    if luigis_pizza>marios_pizza:
        print('Luigi has won the bet.')
    else:
        print('Mario has won the bet.')


if __name__ == '__main__':
    main()

