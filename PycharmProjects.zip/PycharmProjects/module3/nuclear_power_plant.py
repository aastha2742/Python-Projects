# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: NUCLEAR POWER PLANT

def three_prints (string):
    print (string)


three_prints(('NUCLEAR CORE UNSTABLE!!! \nQuarantine is in effect. \nSurrounding hamlets will be evacuated. \nAnti-radiationsuits and iodine pills are mandatory.'))
three_prints(('NUCLEAR CORE UNSTABLE!!! \nQuarantine is in effect. \nSurrounding hamlets will be evacuated. \nAnti-radiationsuits and iodine pills are mandatory.'))
three_prints(('NUCLEAR CORE UNSTABLE!!! \nQuarantine is in effect. \nSurrounding hamlets will be evacuated. \nAnti-radiationsuits and iodine pills are mandatory.'))