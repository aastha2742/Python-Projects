# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: SUM NUMBERS

# def sum_to(n) :
#     pass  # <- fix me

def sum_to(n):
    sum = 0
    numbers_list = [i+1 for i in range(n)]
    for number in numbers_list:
        sum+=number
    return (sum)

