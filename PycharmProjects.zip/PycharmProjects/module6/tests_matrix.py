import unittest
from matrix import Matrix


class TestsStudent(unittest.TestCase):
    a = Matrix([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    b = Matrix([[2, 4, 6], [8, 10, 12], [14, 16, 18]])
    c = Matrix([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
    d = Matrix([[1, 2, 3], [2, 1, 3], [3, 2, 1]])
    e = Matrix([[0,0, 0, 1], [0, 0, 1, 0], [0, 1, 0, 0],[1,0,0,0]])
    f = Matrix([[1,2,3],[2,3,1],[3,2,1],[1,3,2]])


    def test_str(self):
        self.assertEqual(str(self.a), ' 1  2  3\n 4  5  6\n 7  8  9\n')
        self.assertEqual(str(self.b), ' 2  4  6\n 8 10 12\n14 16 18\n')
        self.assertEqual(str(self.c), ' 1  0  0\n 0  1  0\n 0  0  1\n')

    def test_scale(self):
        self.assertEqual(str(self.c.scale(10)), '10  0  0\n 0 10  0\n 0  0 10\n')
        self.assertEqual(str(self.c.scale(25)), '25  0  0\n 0 25  0\n 0  0 25\n')
        self.assertEqual(str(self.c.scale(40)), '40  0  0\n 0 40  0\n 0  0 40\n')
        self.assertEqual(str(self.a.scale(2)), ' 2  4  6\n 8 10 12\n14 16 18\n')
        self.assertEqual(str(self.a.scale(1)), ' 1  2  3\n 4  5  6\n 7  8  9\n')
        self.assertEqual(str(self.e.scale(2)), ' 0  0  0  2\n 0  0  2  0\n 0  2  0  0\n 2  0  0  0\n')


    def test_transpose(self):
        self.assertEqual(str(self.a.transpose()), ' 1  4  7\n 2  5  8\n 3  6  9\n')
        self.assertEqual(str(self.b.transpose()), ' 2  8 14\n 4 10 16\n 6 12 18\n')
        self.assertEqual(str(self.c.transpose()), ' 1  0  0\n 0  1  0\n 0  0  1\n')
        self.assertEqual(str(self.a.transpose().transpose()), ' 1  2  3\n 4  5  6\n 7  8  9\n')
        self.assertEqual(str(self.e.transpose()), ' 0  0  0  1\n 0  0  1  0\n 0  1  0  0\n 1  0  0  0\n')
        self.assertEqual(str(self.f.transpose()), ' 1  2  3  1\n 2  3  2  3\n 3  1  1  2\n')



    def test_multiply(self):
        self.assertEqual(str(self.d.multiply(self.d)), '14 10 12\n13 11 12\n10 10 16\n')
        self.assertEqual(str(self.d.multiply(self.c)), ' 1  2  3\n 2  1  3\n 3  2  1\n')
        self.assertEqual(str(self.e.multiply(self.e)), ' 1  0  0  0\n 0  1  0  0\n 0  0  1  0\n 0  0  0  1\n')
        self.assertEqual(str(self.e.multiply(self.f)), ' 1  3  2\n 3  2  1\n 2  3  1\n 1  2  3\n')
        self.assertEqual(self.d.multiply(self.f), None)
