import unittest
from student import Student, Class


class TestsStudent(unittest.TestCase):
    mary = Student("Mary", 15789613, [10, 9, 8, 10, 9, 10], 9)
    alice = Student("Alice", 1235233, [10, 9, 9, 9, 8, 7], 7)
    anne = Student("Anne", 12655232, [10, 9, 5, 10, 5, 5], 8)
    bob = Student("Bob", 1235232, [10, 9, 7, 9, 8, 9], 5)
    charlie = Student("Charlie", 13655232, [10, 7, 6, 7, 9, 6], 5.5)


    def test_initializer(self):
        self.assertEqual(self.mary.name, "Mary")
        self.assertEqual(self.mary.student_nr, 15789613)
        self.assertEqual(self.mary.points_per_assignment, [10, 9, 8, 10, 9, 10])
        self.assertEqual(self.mary.exam_grade, 9)

        self.assertEqual(self.alice.name, "Alice")
        self.assertEqual(self.alice.student_nr, 1235233)
        self.assertEqual(self.alice.points_per_assignment, [10, 9, 9, 9, 8, 7])
        self.assertEqual(self.alice.exam_grade, 7)

        self.assertEqual(self.anne.name, "Anne")
        self.assertEqual(self.anne.student_nr, 12655232)
        self.assertEqual(self.anne.points_per_assignment, [10, 9, 5, 10, 5, 5])
        self.assertEqual(self.anne.exam_grade, 8)


        self.assertEqual(self.bob.name, "Bob")
        self.assertEqual(self.bob.student_nr, 1235232)
        self.assertEqual(self.bob.points_per_assignment, [10, 9, 7, 9, 8, 9])
        self.assertEqual(self.bob.exam_grade, 5)


        self.assertEqual(self.charlie.name, "Charlie")
        self.assertEqual(self.charlie.points_per_assignment, [10, 7, 6, 7, 9, 6])
        self.assertEqual(self.charlie.student_nr, 13655232)
        self.assertEqual(self.charlie.exam_grade, 5.5)

    def test_course_points(self):
        self.assertEqual(self.mary.course_points(), 121)
        self.assertEqual(self.alice.course_points(), 109)
        self.assertEqual(self.bob.course_points(), 111)
        self.assertEqual(self.charlie.course_points(), 95)
        self.assertEqual(self.anne.course_points(), 88)

    def test_grade(self):
        self.assertEqual(self.mary.grade(), 9.5)
        self.assertEqual(self.alice.grade(), 7.5)
        self.assertEqual(self.bob.grade(), "NVD")
        self.assertEqual(self.charlie.grade(), 6)
        self.assertEqual(self.anne.grade(), "NVD")

    def test_result(self):
        self.assertEqual(self.mary.result(), "Mary (15789613) has scored 9.5 on X_401096")
        self.assertEqual(self.alice.result(), "Alice (1235233) has scored 7.5 on X_401096")
        self.assertEqual(self.bob.result(), "Bob (1235232) has scored NVD on X_401096")
        self.assertEqual(self.charlie.result(), "Charlie (13655232) has scored 6.0 on X_401096")
        self.assertEqual(self.anne.result(), "Anne (12655232) has scored NVD on X_401096")

    def test_passes(self):
        self.assertTrue(self.mary.passes())
        self.assertTrue(self.alice.passes())
        self.assertTrue(not self.bob.passes())
        self.assertTrue(self.charlie.passes())
        self.assertTrue(not self.anne.passes())

    def test_scores_higher_than(self):
        self.assertTrue(self.mary.scores_higher_than(self.alice))
        self.assertTrue(self.mary.scores_higher_than(self.alice))
        self.assertTrue(self.mary.scores_higher_than(self.bob))
        self.assertTrue(self.mary.scores_higher_than(self.charlie))
        self.assertTrue(self.mary.scores_higher_than(self.anne))
        self.assertTrue(self.charlie.scores_higher_than(self.bob))
        self.assertTrue(self.charlie.scores_higher_than(self.anne))
        self.assertTrue(self.alice.scores_higher_than(self.charlie))

    def test_class(self):
        students = [self.mary, self.alice, self.bob, self.charlie, self.anne]
        c = Class()
        for student in students :
            c.add_student(student)
        self.assertEqual(c.pass_rate(), 3/5)
        students = [self.mary, self.alice, self.charlie, self.anne]
        c = Class()
        for student in students :
            c.add_student(student)
        self.assertEqual(c.pass_rate(), 3/4)
        students = [self.mary, self.alice, self.charlie]
        c = Class()
        for student in students:
            c.add_student(student)
        self.assertEqual(c.pass_rate(), 1)




if __name__ == '__main__':
    unittest.main()
