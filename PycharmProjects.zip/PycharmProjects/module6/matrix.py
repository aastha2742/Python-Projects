class Matrix:
    def __init__(self, rows):
        pass

    def __str__(self):
        pass

    def scale(self, w):
        pass

    def transpose(self):
        pass

    def multiply(self, b):
        pass

    # repr is similar to __str__, but __str__ is used  when
    # printing a value, __repr__ when showing a value in
    # the interpreter.
    # repr is intended to be an unambiguous, complete representation
    # of the object, while str is intended to be nicely readable
    # for this object they are the same
    def __repr__(self):
        return str(self)


if __name__ == "__main__":
    pass
