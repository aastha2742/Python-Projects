class LifeGeneration:
    # fill in this class yourself
    def __init__(self, state):
        pass

    def next_generation(self):
        pass

    def board(self):
        pass


class LifeHistory:
    # fill in this class yourself
    def __init__(self, initial_gen):
        pass

    def nr_generations(self):
        pass

    def get_generation(self, i):
        pass

    def dies_out(self):
        pass

    def period(self):
        pass

    def play_out(self, max_steps):
        pass

    def all_boards(self):
        pass
