class Student:

    def __init__(self, name, student_nr, points_per_assignment, exam_grade):
        pass

    def course_points(self):
        pass

    def grade(self):
        pass

    def result(self):
        pass

    def passes(self):
        pass

    def scores_higher_than(self, b):
        pass


if __name__ == "__main__":
    # put test code here
    mary = Student("Mary", 15789613, [10, 9, 8, 10, 9, 10], 9)
    alice = Student("Alice", 1235233, [10, 9, 9, 9, 8, 7], 7)
    bob = Student("Bob", 1235232, [10, 9, 7, 9, 8, 9], 5)
    charlie = Student("Charlie", 13655232, [10, 7, 6, 7, 9, 6], 5.5)
    anne = Student("Anne", 12655232, [10, 9, 5, 10, 5, 5], 8)


class Class:
    def __init__(self):
        pass

    def add_student(self, student):
        pass

    def pass_rate(self):
        pass
