# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: PLUMBER

call_out_cost = 16
hourly_wage = float(input('Enter the hourly wages: '))
billed_hours = float(input('Enter the number of hours worked: '))

if billed_hours % 1 == 0.5:
    billed_hours = float(((10 * billed_hours - 0.5) + 1) / 10.0)

total_cost = (round(billed_hours) * hourly_wage) + call_out_cost

# print('The total cost of this repair is:',REPAIR_COST,'euro')
print(format(total_cost, '.2f'))