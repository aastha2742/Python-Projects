# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: Vat

VAT_TAX_AMOUNT = .21
vat_tax_percent = "{:.2%}".format(VAT_TAX_AMOUNT)
price = int(input('Enter the price of an article including VAT: '))
price_before_tax = format(price / (1 + VAT_TAX_AMOUNT), '.2f')
print('This article will cost ', price_before_tax, 'euro without', vat_tax_percent, 'VAT.')