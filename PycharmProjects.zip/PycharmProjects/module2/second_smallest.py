# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: SECOND SMALLEST

numbers = ''

while len(numbers.split()) < 3:
    numbers = input('Please enter some numbers: ')

list_of_numbers = sorted(list(map(int, numbers.split())))
print(list_of_numbers[1])
