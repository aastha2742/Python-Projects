# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: OTHELLO 1

WHITE = float(input('Enter the number of white pieces on the board: '))
BLACK = float(input('Enter the number of black pieces on the board: '))


print('The percentage of black pieces on the board is:',"{:.2%}".format(BLACK/64))
print('The percentage of black pieces of all the pieces on the board is:',"{:.2%}".format(BLACK/(BLACK+WHITE)))

