# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: OTHELLO 2

black_time = float(input('Enter the time the black player thought: '))
white_time = float(input('Enter the time the white player thought: '))

if black_time < white_time:
    human_time = white_time
else:
    human_time = black_time

human_seconds = int(human_time / 1000)
hours = 0
minutes = 0
seconds = 0
while human_seconds != 0:
    if seconds < 59:
        seconds += 1
    elif minutes < 59:
        minutes += 1
        seconds = 0
    else:
        hours += 1
        minutes = 0
        seconds = 0
    human_seconds -= 1

print('The time the human player has spent thinking is:', "{:02d}".format(hours),':',"{:02d}".format(minutes),':',"{:02d}".format(seconds))
