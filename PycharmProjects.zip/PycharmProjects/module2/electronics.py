# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: ELECTRONICS

first_article = float(input('Enter the price of the first article: '))
second_article = float(input('Enter the price of the second article: '))
third_artcle = float(input('Enter the price of the third article: '))
DISCOUNT = 0.15
money_saved = 0

if first_article > second_article and first_article > third_artcle:
    money_saved = first_article * DISCOUNT
    first_article = first_article - money_saved
elif second_article > first_article and second_article > third_artcle:
    money_saved = second_article * DISCOUNT
    second_article = second_article - money_saved
else:
    money_saved = third_artcle * DISCOUNT
    third_artcle = third_artcle - money_saved

print('Discount:', format(money_saved, '.2f'))
TOTAL = first_article + second_article + third_artcle
print('Total:', format(TOTAL, '.2f'))


