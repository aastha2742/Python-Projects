# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: COLLATZ

n = float(input('Please enter a number: '))


while n != 1:
    if n % 2 == 0:
        print(int(n), end=' ')
        n /= 2
        continue
    print(int(n), end=' ')
    n = 3 * n + 1
print(1)