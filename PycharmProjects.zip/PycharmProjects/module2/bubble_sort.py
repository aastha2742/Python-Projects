# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: BUBBLE SORT

numbers = input('Please enter some numbers: ')
list_of_numbers = numbers.split(' ')
counter = 1

while counter != 0:
    counter = 0
    for i in range(len(list_of_numbers) - 1):
        list_of_numbers[i] = int(list_of_numbers[i])
        list_of_numbers[i + 1] = int(list_of_numbers[i + 1])
        if list_of_numbers[i] > list_of_numbers[i + 1]:
            counter += 1
            list_of_numbers[i], list_of_numbers[i+1] = list_of_numbers[i+1], list_of_numbers[i]

print(list_of_numbers)
