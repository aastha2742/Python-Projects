# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: MANNY

donation = 0

while donation < 50:
    donation = float(input('Enter the amount you want to donate: '))

print('Thank you very much for your contribution of', format(donation, '.2f'), 'euro')






