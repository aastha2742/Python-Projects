# Astha Patel 2658876
# Created at 11/11/2021
# Program Name: ALPHABET

alphabet = ''
for i in range(97, 97 + 26):
    alphabet += chr(i)

print(alphabet)